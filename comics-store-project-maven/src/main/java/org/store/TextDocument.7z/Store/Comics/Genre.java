package org.store.Store.Comics;

public enum Genre {
    SUPERHERO,
    SCIENCE_FICTION,
    FANTASY,
    HORROR,
    NOIR,
    SLICE_OF_LIFE,
    HISTORICAL,
    ROMANCE,
    ADVENTURE,
    Comedy;

}
