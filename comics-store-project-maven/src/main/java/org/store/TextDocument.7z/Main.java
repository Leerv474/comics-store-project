package org.store;

import org.store.Store.StoreAPI;
import org.store.TextDocument.DocumentAPI;

public class Main {
    public static void main(String[] args) {
        StoreAPI.start();
//        DocumentAPI.startDocumentAPI();
    }
}

